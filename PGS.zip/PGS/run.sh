#!/bin/sh
python src/PGS.py ${@}