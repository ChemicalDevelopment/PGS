import argparse
import json
import pyrebase
import time
from collections import namedtuple
from extra import extra
import glbl

def main():

	parser = argparse.ArgumentParser(description="PGS Gen Workloads", version="DEV", add_help=True)
	parser.add_argument('-p', '--prefs', type=str, default="my.prefs", help='Preferences file')
	parser.add_argument('-bs', '--bs', type=int, default=[5000, 5000, 5000], help='Block size')
	parser.add_argument('-bo', '--bo', type=int, default=[0, 0, 0], help='Block offsets')
	parser.add_argument('-bom', '--bom', type=int, default=[50000, 50000, 50000], help='Block max')

	args = parser.parse_args()

	prefs = extra.DictToObject(**json.load(open(args.prefs)))
	glbl.init()

	appConfig = {
		# public API key
		"apiKey": "AIzaSyC6R2fqZN9eRFzr88nebDqvA_VwNKtzJQY",
		"authDomain": "pgsdb-c4faf.firebaseapp.com",
		"databaseURL": "https://pgsdb-c4faf.firebaseio.com",
		"storageBucket": "pgsdb-c4faf.appspot.com"
	}
	glbl.firebase = pyrebase.initialize_app(appConfig)
	glbl.usr = glbl.firebase.auth().sign_in_with_email_and_password(prefs.email, prefs.password)
	extra.AutoRefresh()

	def workload(a, b, c):
		return { "offsets": [a, b, c], "ranges": args.bs, "_progress": 0, "_state": "none", "_changed": int(time.time() * 1000) }

	for i in range(args.bo[0], args.bo[0]+args.bom[0], args.bs[0]):
		for j in range(args.bo[1], args.bo[1]+args.bom[1], args.bs[1]):
			for k in range(args.bo[2], args.bo[2]+args.bom[2], args.bs[2]):
				glbl.firebase.database().child("workloads").push(workload(i, j, k))

if __name__ == "__main__":
	exit(main())

